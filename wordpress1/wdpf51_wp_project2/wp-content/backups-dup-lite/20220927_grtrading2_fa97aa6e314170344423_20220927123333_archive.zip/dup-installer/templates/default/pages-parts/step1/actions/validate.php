<?php

/**
 *
 * @package templates/default
 *
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="validate_action" class="bottom-step-action margin-top-2" >
    <div class="footer-buttons" >
        <div class="content-left">
        </div>
        <div class="content-right" >
            <button id="validate-button" type="button" class="default-btn">
                Validate <i class="far fa-check-circle"></i>
            </button>
        </div>
    </div>
</div>